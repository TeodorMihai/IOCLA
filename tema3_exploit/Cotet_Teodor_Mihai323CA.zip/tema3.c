#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SUMASCII 999
#define LEN_NUME 5
#define LEN_PRENUME 5
#define GRUPA 3

int secret_func1()
{
	puts("Well done!");
	fflush(stdout);
	return 0;
}

int secret_func2(int a, int b, int c, int d)
{
	if (a == SUMASCII && b == SUMASCII*LEN_NUME && c == SUMASCII*LEN_PRENUME && d == SUMASCII*GRUPA)
		puts("Well done again!");
	else
		puts("It seems not skilled enough, you are.");

	fflush(stdout);
	return 0;
}

int check_pass(char pass[15])
{
	char stored_pass[15] = {0x63, 0x69, 0x71, 0x6c, 0x5f, 0x0c, 0x63, 0x5c, 0x2a, 0x76, 0x29, 0x7c, 0x27, 0x3f, 0x33};
	int i = 0;
	int j = 42;

	for (i = 0; i < 15; i++, j+=3) {
		pass[i] ^= j;
	}
	return strncmp(pass, stored_pass, 15);
}

int login(void)
{
	char name[LEN_NUME];
	char pass[17+LEN_PRENUME];

	puts("Who are you?");
	fgets(name, LEN_NUME, stdin);

	if (name[0] != 0x52 || name[1] != 0x44) {
		puts("Sorry, but you are not the One.");
		return 2;
	}

	puts("Prove it with a password: ");
	fgets(pass, 16, stdin);

	if(check_pass(pass)) {
		puts("Ha, I knew you are not the One.");
		fflush(stdout);
		return 4;
	}

	puts("I bow to you, oh great One.");
	fflush(stdout);

	return 0;
}

void play(void)
{
	int parrot = SUMASCII*GRUPA;
	char buf[(LEN_NUME+LEN_PRENUME)*GRUPA];
	char c;

	puts("Command me:");

	while ((c = getchar()) != '\n' && c != EOF);
	gets(buf);

	if (parrot != SUMASCII*GRUPA) {
		puts("[parrot] SQUAACK, SECURITY ALERT, SECURITY ALERT");
		exit(-1);
	}

	puts("It shall be done.");
}

int main(int argc, char* argv[])
{
	const char * prenume = "I am not Mihai";
	const char * tahw_ni_hsilgne_kaeps_yeht_od = "?tahw"; // I wonder if this can be useful in any way...

	if(login())
		exit(-1);

	play();

	return 0;
}
