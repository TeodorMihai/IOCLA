import sys
import os

if len(sys.argv) != 4:
	print "Usage %s <nume> <prenume> <cifra_grupa>" % sys.argv[0]
	exit(1)

nume = sys.argv[1]
prenume = sys.argv[2]
grupa = sys.argv[3]

def sumascii(s):
	res = 0
	for i in s:
		res += ord(i)
	return res

def_sumascii = '#define SUMASCII ' + str(sumascii(nume + prenume))
def_len_nume = '#define LEN_NUME ' + str(len(nume))
def_len_prenume = '#define LEN_PRENUME ' + str(len(prenume))
def_grupa = '#define GRUPA ' + str(int(grupa, 10))

const_prenume = 'const char * prenume = "I am not ' + prenume + '";'
const_what = 'const char * tahw_ni_hsilgne_kaeps_yeht_od = "?tahw"; // I wonder if this can be useful in any way...'

lines = [line.rstrip() for line in open('seed.c', 'r')]
res = ''
for i in lines:
	if i == '!delimiter':
		res += def_sumascii+'\n'
		res += def_len_nume+'\n'
		res += def_len_prenume+'\n'
		res += def_grupa+'\n'
	elif i == '!what':
		res += '\t'+const_prenume+'\n'
		res += '\t'+const_what+'\n'
	else:
		res += i
		res += '\n'
with open('tema3.c','w') as f:
	f.write(res)
